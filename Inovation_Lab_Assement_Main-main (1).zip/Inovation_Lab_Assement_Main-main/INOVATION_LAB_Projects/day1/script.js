var inputbox = parseInt(document.getElementById("input-box1").value)
var inputbox2 = parseInt(document.getElementById("input-box2").value)
function add1(){
    var inputbox = parseInt(document.getElementById("input-box1").value)
var inputbox2 = parseInt(document.getElementById("input-box2").value)
    console.log(inputbox + inputbox2)
}
function sub1(){
    var inputbox = parseInt(document.getElementById("input-box1").value)
var inputbox2 = parseInt(document.getElementById("input-box2").value)
    console.log(inputbox  - inputbox2)
}
function mul(){
    var inputbox = parseInt(document.getElementById("input-box1").value)
var inputbox2 = parseInt(document.getElementById("input-box2").value)
    console.log(inputbox * inputbox2) 
}
function div1(){
    var inputbox = parseInt(document.getElementById("input-box1").value)
var inputbox2 = parseInt(document.getElementById("input-box2").value)
    console.log(inputbox / inputbox2)
}

